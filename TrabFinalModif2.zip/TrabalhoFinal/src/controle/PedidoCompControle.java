package controle;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import dao.PedidoCompDAO;
import modelo.PedidoComp;
import visao.JanelaPrincipal;

public class PedidoCompControle implements ActionListener {

	private JanelaPrincipal janela;
	private PedidoComp pc;
	private PedidoCompDAO pcdao;
	
	public PedidoCompControle(JanelaPrincipal janela, PedidoComp pc) {
		this.janela=janela;
		this.janela.getItemPedidoComp().addActionListener(this);
		this.pc=pc;
		pcdao=new PedidoCompDAO();
		
	}
	
	
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if (e.getActionCommand().equals("Pedido de Novo Computador")) {
			janela.getCard().show(janela.getPainelInicial(), "Pedido de Novo Computador");
			

		}

		if (e.getActionCommand().equals("Sair")) {

			System.exit(0);
			
		}
	}

}
