package controle;

import modelo.PedidoComp;
import modelo.Usuario;
import visao.JanelaPrincipal;

public class App {
	
	public static void main(String[] args) {
		
		JanelaPrincipal jp = new JanelaPrincipal();
		jp.setVisible(true);
		Usuario u1=new Usuario();
		UsuarioControle uc=new UsuarioControle(jp,u1);
		PedidoComp pc=new PedidoComp();
		PedidoCompControle pccont=new PedidoCompControle(jp,pc);
		
		
		
	}

}
