package controle;

import java.awt.CardLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JPanel;

import dao.UsuarioDAO;
import modelo.Usuario;
import visao.JanelaPrincipal;

public class UsuarioControle implements ActionListener {

	private JanelaPrincipal janela;
	private Usuario usuario;
	private UsuarioDAO usudao;
	

	public UsuarioControle(JanelaPrincipal janela, Usuario usuario) {

		this.janela = janela;
		this.usuario = usuario;
		usudao = new UsuarioDAO();
		this.janela.getItemAutenticar().addActionListener(this);
		this.janela.getItemSair().addActionListener(this);
		
	
	}

	public void autenticaUsuario() {

	}

	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if (e.getActionCommand().equals("Autenticar")) {
			janela.getCard().show(janela.getPainelInicial(), "Autenticar");
			

		}

		if (e.getActionCommand().equals("Sair")) {

			System.exit(0);
			
		}
	}
}
