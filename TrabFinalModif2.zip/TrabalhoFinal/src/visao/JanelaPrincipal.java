package visao;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.CardLayout;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;

public class JanelaPrincipal extends JFrame {

	private JPanel painelInicial;
	private JanelaAutenticar autentica;
	private JanelaPedidoComp janpc;
	private CardLayout card;
	private JMenuBar menuBar;
	private JMenu menuPrincipal, menuPROPLAN;
	private JMenuItem itemAutenticar, itemPedidoComp, itemPedidoInst;
	private JMenuItem itemSair;
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		
		JanelaPrincipal janpri=new JanelaPrincipal();
		janpri.setVisible(true);
		
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					JanelaPrincipal frame = new JanelaPrincipal();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public JanelaPrincipal() {
		setTitle("Sistema de Pedidos Internos");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 665, 658);
		
		menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		menuPrincipal = new JMenu("Principal");
		menuBar.add(menuPrincipal);
		
		itemAutenticar = new JMenuItem("Autenticar");
		menuPrincipal.add(itemAutenticar);
		
		itemSair = new JMenuItem("Sair");
		menuPrincipal.add(itemSair);
		
		JMenu menuASCOM = new JMenu("ASCOM");
		menuBar.add(menuASCOM);
		
		JMenu menuEngenharia = new JMenu("Engenharia");
		menuBar.add(menuEngenharia);
		
		menuPROPLAN = new JMenu("PROPLAN");
		menuBar.add(menuPROPLAN);
		
		itemPedidoComp = new JMenuItem("Pedido de Novo Computador");
		menuPROPLAN.add(itemPedidoComp);
		
		itemPedidoInst = new JMenuItem("Pedido de Instalação Provisória");
		menuPROPLAN.add(itemPedidoInst);
		
		JMenu menuSEI = new JMenu("SEI");
		menuBar.add(menuSEI);
		painelInicial = new JPanel();
		painelInicial.setBorder(new EmptyBorder(5, 5, 5, 5));

		painelInicial = new JPanel();
		setContentPane(painelInicial);
		card=new CardLayout();
		painelInicial.setLayout(card);
        
		
        autentica=new JanelaAutenticar();
        janpc=new JanelaPedidoComp();
        painelInicial.add(new JPanel(),"Início");
        painelInicial.add(autentica,"Autenticar");
        painelInicial.add(janpc,"Pedido de Novo Computador");
      
        
        
	}

	public JPanel getPainelInicial() {
		return painelInicial;
	}

	public void setPainelInicial(JPanel painelInicial) {
		this.painelInicial = painelInicial;
	}

	public JPanel getAutentica() {
		return autentica;
	}

	public void setAutentica(JanelaAutenticar autentica) {
		this.autentica =autentica;
	}

	public CardLayout getCard() {
		return card;
	}

	public void setCard(CardLayout card) {
		this.card = card;
	}


	public JMenu getMenuPrincipal() {
		return menuPrincipal;
	}

	public void setMenuPrincipal(JMenu menuPrincipal) {
		this.menuPrincipal = menuPrincipal;
	}

	public JMenu getMenuPROPLAN() {
		return menuPROPLAN;
	}

	public void setMenuPROPLAN(JMenu menuPROPLAN) {
		this.menuPROPLAN = menuPROPLAN;
	}

	public JMenuItem getItemAutenticar() {
		return itemAutenticar;
	}

	public void setItemAutenticar(JMenuItem itemAutenticar) {
		this.itemAutenticar = itemAutenticar;
	}

	public JMenuItem getItemPedidoComp() {
		return itemPedidoComp;
	}

	public void setItemPedidoComp(JMenuItem itemPedidoComp) {
		this.itemPedidoComp = itemPedidoComp;
	}

	public JMenuItem getItemPedidoInst() {
		return itemPedidoInst;
	}

	public void setItemPedidoInst(JMenuItem itemPedidoInst) {
		this.itemPedidoInst = itemPedidoInst;
	}

	public JMenuItem getItemSair() {
		return itemSair;
	}

	public void setItemSair(JMenuItem itemSair) {
		this.itemSair = itemSair;
	}
	
	

}
