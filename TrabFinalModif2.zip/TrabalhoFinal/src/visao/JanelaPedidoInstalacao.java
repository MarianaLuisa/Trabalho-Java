package visao;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

import net.miginfocom.swing.MigLayout;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.BorderLayout;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.ScrollPaneConstants;
import javax.swing.JComboBox;
import javax.swing.JButton;

public class JanelaPedidoInstalacao extends JPanel {

	private JTextField textLotacao2;
	private JTextField textSala2;
	private JTextField textRamal2;
	private JButton buttonEnviar2,buttonCancelar2;
	private JComboBox<String> boxPredio2;

	/**
	 * Create the panel.
	 */
	public JanelaPedidoInstalacao() {
		setLayout(new MigLayout("", "[right]", "[][][][][][][][][][][][][][][][][][]"));
		
		JLabel labelPedido2 = new JLabel("PROPLAN - PEDIDO INSTALAÇÃO PROVISÓRIA");
		labelPedido2.setFont(new Font("Tahoma", Font.BOLD, 17));
		add(labelPedido2, "cell 0 0,alignx center,aligny center");
		
		JLabel labelSolicitacao2 = new JLabel("Solicitação de Equipamentos de TIC para evento");
		labelSolicitacao2.setForeground(new Color(0, 0, 0));
		labelSolicitacao2.setBackground(new Color(0, 128, 255));
		labelSolicitacao2.setFont(new Font("Tahoma", Font.PLAIN, 14));
		add(labelSolicitacao2, "cell 0 2,alignx center,aligny center");
		
		JLabel labelLotacao2 = new JLabel("Lotação *");
		add(labelLotacao2, "flowy,cell 0 5,alignx left");
		
		textLotacao2 = new JTextField();
		add(textLotacao2, "cell 0 6,growx");
		textLotacao2.setColumns(50);
		
		JLabel labelSala2 = new JLabel("Sala");
		add(labelSala2, "cell 0 8,alignx left");
		
		textSala2 = new JTextField();
		add(textSala2, "cell 0 9,growx");
		textSala2.setColumns(10);
		
		JLabel labelPredio2 = new JLabel("Prédio");
		add(labelPredio2, "cell 0 11,alignx left");
		
		boxPredio2 = new JComboBox<String>();
		boxPredio2.addItem("----");
		boxPredio2.addItem("Prédio 1");
		boxPredio2.addItem("Prédio 2");
		boxPredio2.addItem("Prédio 3");
		add(boxPredio2, "cell 0 12,growx");
		
		JLabel labelRamal2 = new JLabel("Ramal");
		add(labelRamal2, "cell 0 14,alignx left");
		
		textRamal2 = new JTextField();
		add(textRamal2, "cell 0 15,growx");
		textRamal2.setColumns(10);
		
		buttonEnviar2 = new JButton("Enviar");
		add(buttonEnviar2, "flowx,cell 0 17,alignx center");
		
		buttonCancelar2 = new JButton("Cancelar");
		add(buttonCancelar2, "cell 0 17");
		
		//JScrollPane scrollPane = new JScrollPane();
		//scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS); 
		//add(scrollPane, "flowy,cell 0 0, aligny right");
		

	}

	public JTextField getTextLotacao2() {
		return textLotacao2;
	}

	public void setTextLotacao2(JTextField textLotacao2) {
		this.textLotacao2 = textLotacao2;
	}

	public JTextField getTextSala2() {
		return textSala2;
	}

	public void setTextSala2(JTextField textSala2) {
		this.textSala2 = textSala2;
	}

	public JTextField getTextRamal2() {
		return textRamal2;
	}

	public void setTextRamal2(JTextField textRamal2) {
		this.textRamal2 = textRamal2;
	}

	public JButton getButtonEnviar2() {
		return buttonEnviar2;
	}

	public void setButtonEnviar2(JButton buttonEnviar2) {
		this.buttonEnviar2 = buttonEnviar2;
	}

	public JButton getButtonCancelar2() {
		return buttonCancelar2;
	}

	public void setButtonCancelar2(JButton buttonCancelar2) {
		this.buttonCancelar2 = buttonCancelar2;
	}

	public JComboBox<String> getBoxPredio2() {
		return boxPredio2;
	}

	public void setBoxPredio2(JComboBox<String> boxPredio2) {
		this.boxPredio2 = boxPredio2;
	}
	
	

}
