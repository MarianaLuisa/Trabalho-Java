package dao;

public class PedidoInstDAO {

}
