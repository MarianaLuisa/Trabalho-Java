package dao;

public class PedidoCompDAO {

}
