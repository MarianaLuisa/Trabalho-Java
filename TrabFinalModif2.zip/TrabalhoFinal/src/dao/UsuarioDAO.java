package dao;

public class UsuarioDAO {

}
