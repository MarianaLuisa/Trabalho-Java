package modelo;

public class PedidoComp {
	
	private String lot,sala,predio,ramal,desc;

	public PedidoComp(String lot, String sala, String predio, String ramal, String desc) {
		super();
		this.lot = lot;
		this.sala = sala;
		this.predio = predio;
		this.ramal = ramal;
		this.desc = desc;
	}
	
	public PedidoComp(){
		
	}

	public String getLot() {
		return lot;
	}

	public void setLot(String lot) {
		this.lot = lot;
	}

	public String getSala() {
		return sala;
	}

	public void setSala(String sala) {
		this.sala = sala;
	}

	public String getPredio() {
		return predio;
	}

	public void setPredio(String predio) {
		this.predio = predio;
	}

	public String getRamal() {
		return ramal;
	}

	public void setRamal(String ramal) {
		this.ramal = ramal;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}
	
	

}
