package modelo;

public class Usuario {
	
	private String usu,senha;

	public Usuario(String usu, String senha) {
		super();
		this.usu = usu;
		this.senha = senha;
	}
	
	public Usuario(){
		
	}

	public String getUsu() {
		return usu;
	}

	public void setUsu(String usu) {
		this.usu = usu;
	}

	public String getSenha() {
		return senha;
	}

	public void setSenha(String senha) {
		this.senha = senha;
	}
	
	public String toString() {
		
		return usu+"#"+senha;
	}

}
